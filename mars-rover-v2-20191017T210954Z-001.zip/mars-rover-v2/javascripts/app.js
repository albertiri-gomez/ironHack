// Rover Object Goes Here
// ======================
var rover;

rover = {
  direction: "N",
  position: {
    x: 0, y: 0
  },
}
var travelLog = [];

var obstacles;
obstacles = {
  x: [1, 1, 4, 3, 2],
  y: [0, 3, 3, 2, 4]
}

function turnLeft() {
  switch (rover.direction) {
    case "N":
      rover.direction = "W";
      break;
    case "W":
      rover.direction = "S";
      break;
    case "S":
      rover.direction = "E";
      break;
    case "E":
      rover.direction = "N";
    default:
  }
  console.log("turnLeft was called!");
}

function turnRight() {
  switch (rover.direction) {
    case "N":
      rover.direction = "E";
      break;
    case "E":
      rover.direction = "S";
      break;
    case "S":
      rover.direction = "W";
      break;
    case "W":
      rover.direction = "N";
    default:
  }
  console.log("turnRight was called!");
}


function moveForward() {
  console.log("moveForward was called");
  if (rover.direction == "N" && rover.y > 0) {
    rover.y--;
    if (obstacles()) rover.y++;
  }
  else if (rover.direction == "E" && rover.x < 10) {
    rover.x++;
    if (obstacles()) rover.x--;
  }
  else if (rover.direction == "S" && rover.y < 10) {
    rover.y++;
    if (obstacles()) rover.y--;
  }
  else if (rover.direction == "W" && rover.x > 0) {
    rover.x--;
    if (obstacles()) rover.x++;
  }
  else {
    console.log("Position bad " + rover.position.x + "," + rover.position.y);
  }
  travelLog.push(rover.x + rover.y);
}

function moveBackward() {
  console.log("moveBackward was called");
  if (rover.direction == "N" && rover.y < 10) {
    rover.y++;
    if (moveObstacles()) rover.y--;
  } else if (rover.direction == "E" && rover.x > 0) {
    rover.x++;
    if (moveObstacles()) rover.x++;
  } else if (rover.direction == "S" && rover.y > 0) {
    rover.y--;
    if (moveObstacles()) rover.y++;
  } else if (rover.direction == "W" && rover.x < 10) {
    rover.x++;
    if (moveObstacles()) rover.x--;
  } else {
    console.log("position bad " + rover.position.x + "," + rover.position.y);
  }
  travelLog.push(rover.position.x + rover.position.y);
}

function goForward(comandos) {
  var comandosM = comandos.toUpperCase();
  
    for (var i = 0; i < comandosM.length; i++) {
      console.log(comandosM[i])
      switch (comandosM[i]) {
        case "F":
          moveForward();
          break;
        case "R":
          turnRight();
          break;
        case "L":
          turnLeft();
          break;
        case "B":
          moveBackward();
          break;
        default:
          console.log("invalid character");
      }

      travelLog.push(rover.position);
      console.log("direccion: ", rover.direction);
    }

    console.log(travelLog);
  }


function moveObstacles() {
  for (var i = 0; j < obstacles.x.length; i++) {

    if (rover.x == obstacles.x[i] && rover.y == obstacles.y[i]) {
      console.log("obstacle");
      return true;

    }
  } return false;
}

goForward("LLFBLLW");
